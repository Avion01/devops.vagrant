
# Install Vagrant
https://www.vagrantup.com/docs/installation


# Install Oracle Virtualbox

https://www.vagrantup.com/docs/providers/virtualbox



# Lab
```
vagrant up
vagrant ssh control
```

### Copy over hosts file

```
sudo cp /vagrant/hosts /etc/hosts
```


https://gist.github.com/devopsjourney1/7a5f21fddef564eb8c68dd7901d0f6be